"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Home, Settings, CheckCircle, Clock, Award, Phone, Mail, Calendar } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export default function ProposalPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const [progress, setProgress] = useState(0)
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    // Simulate loading progress
    const timer = setTimeout(() => {
      setIsLoaded(true)
    }, 1000)

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          return 100
        }
        return prev + 5
      })
    }, 50)

    return () => {
      clearTimeout(timer)
      clearInterval(interval)
    }
  }, [])

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.1,
        duration: 0.5,
      },
    }),
  }

  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex flex-col items-center justify-center p-4">
        <div className="w-full max-w-md text-center">
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
            <h2 className="text-2xl font-bold text-white mb-4">Loading Proposal</h2>
            <Progress value={progress} className="h-2 mb-2" />
            <p className="text-gray-300">{progress}% Complete</p>
          </motion.div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800">
      <header className="border-b border-white/10 backdrop-blur-md sticky top-0 z-10 bg-black/20">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="flex items-center"
          >
            <div className="h-10 w-10 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 flex items-center justify-center mr-3">
              <span className="text-white font-bold">A</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Arabesque Gallery</h1>
              <p className="text-sm text-gray-400">E-Commerce Proposal</p>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5 }}>
            <Badge variant="outline" className="bg-white/10 text-white border-white/20 px-3 py-1">
              <Calendar className="h-3 w-3 mr-1" />
              April 27, 2025
            </Badge>
          </motion.div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <Tabs defaultValue="overview" className="w-full" onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-5 mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="features">Features</TabsTrigger>
              <TabsTrigger value="pricing">Pricing</TabsTrigger>
              <TabsTrigger value="timeline">Timeline</TabsTrigger>
              <TabsTrigger value="contact">Contact</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6">
              <AnimatePresence mode="wait">
                <motion.div
                  key="overview"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <Card className="border-0 shadow-lg bg-white/5 backdrop-blur-md">
                      <CardHeader>
                        <CardTitle className="text-white text-2xl">Project Summary</CardTitle>
                        <CardDescription className="text-gray-400">
                          Custom E-Commerce Website for Arabesque Gallery
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="text-gray-300">
                        <p className="mb-4">
                          This proposal outlines the complete development of a custom e-commerce website specialized in
                          selling Arabesque products from Egypt to customers in the United States.
                        </p>
                        <p className="mb-4">
                          The website is crafted with a modern tech stack, responsive design, a secure order system, and
                          user account features, providing a high-end shopping experience.
                        </p>
                        <div className="mt-6 space-y-3">
                          <div className="flex items-center">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                            <span>Modern Tech Stack (Next.js 14, TypeScript)</span>
                          </div>
                          <div className="flex items-center">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                            <span>Responsive Design for All Devices</span>
                          </div>
                          <div className="flex items-center">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                            <span>Secure Payment Processing with Stripe</span>
                          </div>
                          <div className="flex items-center">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                            <span>User Account System with Clerk</span>
                          </div>
                          <div className="flex items-center">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                            <span>Admin Dashboard for Product Management</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="space-y-8">
                      <Card className="border-0 shadow-lg bg-white/5 backdrop-blur-md overflow-hidden">
                        <CardHeader className="bg-gradient-to-r from-purple-600/20 to-indigo-600/20 pb-2">
                          <CardTitle className="text-white">Ongoing Support Commitment</CardTitle>
                        </CardHeader>
                        <CardContent className="pt-4">
                          <p className="text-gray-300">
                            <span className="font-bold text-purple-400">I am committed to your long-term success.</span>{" "}
                            Unlike other developers who leave after implementation, I will be available anytime you need
                            me for updates, maintenance (bugs), or expansions to your e-commerce platform.
                          </p>
                          <div className="mt-4 p-3 bg-white/10 rounded-md">
                            <p className="text-gray-300 italic">
                              "My relationship with clients extends far beyond project completion. I'm your technology
                              partner for the journey ahead anyway."
                            </p>
                          </div>
                        </CardContent>
                      </Card>

                      <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-600/20 to-indigo-600/20 backdrop-blur-md">
                        <CardHeader>
                          <CardTitle className="text-white">Why Choose This Solution?</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4 text-gray-300">
                            <div className="flex items-start">
                              <div className="h-8 w-8 rounded-full bg-purple-500/20 flex items-center justify-center mr-3 mt-1">
                                <Award className="h-4 w-4 text-purple-400" />
                              </div>
                              <div>
                                <h3 className="font-medium text-white">Professional Expertise</h3>
                                <p className="text-sm">
                                  Delivering high-quality web solutions with modern technologies and easy edits.
                                </p>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </TabsContent>

            <TabsContent value="features">
              <AnimatePresence mode="wait">
                <motion.div
                  key="features"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {[
                      {
                        title: "Modern Tech Stack",
                        icon: <Settings className="h-6 w-6 text-purple-400" />,
                        items: [
                          "Next.js 14 (React framework)",
                          "TypeScript (structured code)",
                          "Tailwind CSS (responsive styling)",
                          "Clerk for user authentication",
                          "Stripe payment gateway",
                          "Neon Database",
                        ],
                      },
                      {
                        title: "Key Pages",
                        icon: <Home className="h-6 w-6 text-indigo-400" />,
                        items: [
                          "Home Page with hero banner",
                          "Products Page with filters",
                          "Product Detail Pages",
                          "Custom Order Page",
                          "About Us & Contact Pages",
                          "Checkout & Order Confirmation",
                          "Admin Dashboard",
                          "Legal Pages",
                        ],
                      },
                      {
                        title: "Core Systems",
                        icon: <Settings className="h-6 w-6 text-blue-400" />,
                        items: [
                          "Account System",
                          "Achievements System",
                          "Order Management System",
                          "Stripe Payment Integration",
                          "Admin Control Panel",
                          "Product Search & Filtering",
                          "Responsive Design System",
                        ],
                      },
                    ].map((section, i) => (
                      <motion.div key={section.title} custom={i} variants={fadeIn} initial="hidden" animate="visible">
                        <Card className="h-full border-0 shadow-lg bg-white/5 backdrop-blur-md">
                          <CardHeader className="pb-2">
                            <div className="flex items-center">
                              {section.icon}
                              <CardTitle className="text-white ml-2">{section.title}</CardTitle>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <ul className="space-y-2">
                              {section.items.map((item, j) => (
                                <motion.li
                                  key={j}
                                  initial={{ opacity: 0, x: -10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: 0.1 + j * 0.05 }}
                                  className="flex items-center text-gray-300"
                                >
                                  <div className="h-2 w-2 rounded-full bg-purple-500 mr-2"></div>
                                  {item}
                                </motion.li>
                              ))}
                            </ul>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3, duration: 0.5 }}
                    className="mt-8"
                  >
                    <Card className="border-0 shadow-lg bg-gradient-to-r from-purple-600/10 to-indigo-600/10 backdrop-blur-md">
                      <CardHeader>
                        <CardTitle className="text-white">Creative Enhancements</CardTitle>
                        <CardDescription className="text-gray-400">
                          Additional features available for your e-commerce platform
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="bg-white/5 p-4 rounded-lg">
                            <h3 className="text-lg font-medium text-white mb-2">Basic Features (Included)</h3>
                            <p className="text-gray-300">
                              Responsive design, product listings, secure checkout, and user accounts are all included
                              in the base package.
                            </p>
                          </div>

                          <div className="bg-white/5 p-4 rounded-lg">
                            <h3 className="text-lg font-medium text-white mb-2">Premium Features (Additional)</h3>
                            <p className="text-gray-300">
                              Advanced features like 3D product visualization, virtual room designer, and artisan
                              connections are available for an additional fee.
                            </p>
                          </div>

                          <div className="bg-white/5 p-4 rounded-lg">
                            <h3 className="text-lg font-medium text-white mb-2">Custom Integrations</h3>
                            <p className="text-gray-300">
                              Tailored integrations with third-party services and custom functionality can be discussed
                              and quoted separately.
                            </p>
                          </div>

                          <div className="bg-white/5 p-4 rounded-lg">
                            <h3 className="text-lg font-medium text-white mb-2">Future Expansion</h3>
                            <p className="text-gray-300">
                              The platform is built to easily accommodate future enhancements and new features as your
                              business grows.
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              </AnimatePresence>
            </TabsContent>

            <TabsContent value="pricing">
              <AnimatePresence mode="wait">
                <motion.div
                  key="pricing"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <Card className="border-0 shadow-lg bg-white/5 backdrop-blur-md">
                      <CardHeader>
                        <CardTitle className="text-white">Development Breakdown</CardTitle>
                        <CardDescription className="text-gray-400">
                          Detailed cost structure in Egyptian Pounds (EGP)
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {[
                            { task: "Website UI/UX Design", cost: "3,000 EGP" },
                            { task: "Frontend Development (Pages, Features)", cost: "5,500 EGP" },
                            { task: "Backend Development (Auth, Cart, Orders, Stripe)", cost: "4,000 EGP" },
                            { task: "Admin Dashboard Development", cost: "2,000 EGP" },
                            { task: "Testing, Optimization, and Deployment", cost: "500 EGP" },
                          ].map((item, i) => (
                            <motion.div
                              key={i}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.1 + i * 0.1 }}
                              className="flex justify-between items-center pb-2 border-b border-white/10"
                            >
                              <span className="text-gray-300">{item.task}</span>
                              <span className="font-medium text-white">{item.cost}</span>
                            </motion.div>
                          ))}

                          <motion.div
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.6 }}
                            className="flex justify-between items-center pt-2 font-bold"
                          >
                            <span className="text-white">Total</span>
                            <span className="text-xl text-purple-400">15,000 EGP</span>
                          </motion.div>

                          
                          <motion.div
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.7 }}
                            className="mt-4 pt-4 border-t border-dashed border-white/20"
                          >
                            <p className="text-gray-300 font-medium mb-2">Not included:</p>
                            <ul className="text-gray-400 text-sm space-y-1 list-disc pl-5">
                              <li>Hosting services</li>
                              <li>Domain registration</li>
                              <li>Database size upgrades</li>
                              <li>3D models</li>
                            </ul>
                          </motion.div>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="space-y-6">
                      <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-600/20 to-indigo-600/20 backdrop-blur-md">
                        <CardHeader>
                          <CardTitle className="text-white">What's Included</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-2">
                            {[
                              "Complete design and development",
                              "Responsive website for all devices",
                              "Secure user account system",
                              "Full e-commerce functionality",
                              "Stripe payment integration",
                              "Achievements (reward system)",
                              "Admin panel for easy management",
                              "Basic SEO setup",
                              "Image optimization",
                              "7 days of free support after delivery",
                              "Ongoing availability for future needs",
                            ].map((item, i) => (
                              <motion.li
                                key={i}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 0.1 + i * 0.05 }}
                                className="flex items-center text-gray-300"
                              >
                                <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                                {item}
                              </motion.li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>

                      <Card className="border-0 shadow-lg bg-white/5 backdrop-blur-md">
                        <CardHeader>
                          <CardTitle className="text-white">Market Value Comparison</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-4">
                            <div className="flex items-center justify-between">
                              <span className="text-gray-300">Market Rate</span>
                              <span className="text-white font-medium">20,000 - 25,000 EGP</span>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-gray-300">Your Special Price</span>
                              <span className="text-purple-400 font-bold">15,000 EGP</span>
                            </div>
                            <div className="pt-2 mt-2 border-t border-white/10">
                              <div className="text-gray-300 text-sm">
                                <p>
                                  You're receiving a special collaborative rate that's{" "}
                                  <span className="text-green-400 font-medium">25-40% below</span> market value for a
                                  project of this scope and quality.
                                </p>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4, duration: 0.5 }}
                    className="mt-8"
                  >
                    <Card className="border-0 shadow-lg bg-white/5 backdrop-blur-md">
                      <CardHeader>
                        <CardTitle className="text-white">What's Out of Scope</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {[
                            {
                              title: "Shipment Tracking System",
                              description: "Live tracking with carriers like FedEx, DHL, etc. is not included",
                            },
                            {
                              title: "Product Photography",
                              description: "Client must provide professional product photos.",
                            },
                            {
                              title: "Content Writing",
                              description:
                                "All written text — e.g., product descriptions, about us story — should be provided by the client.",
                            },
                            {
                              title: "Advanced Shipping Carrier Integration",
                              description:
                                "Advanced shipping calculations based on distance, package weight, etc. require a separate project.",
                            },
                            {
                              title: "Stripe and Payment Provider Fees",
                              description:
                                "Stripe setup is included, but any payment fees charged by Stripe are the client's responsibility or let's just use SHOPIFY ",
                            },
                          ].map((item, i) => (
                            <motion.div
                              key={i}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.1 + i * 0.1 }}
                              className="bg-white/5 p-4 rounded-lg"
                            >
                              <h3 className="text-white font-medium mb-1">{item.title}</h3>
                              <p className="text-gray-400 text-sm">{item.description}</p>
                            </motion.div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              </AnimatePresence>
            </TabsContent>

            <TabsContent value="timeline">
              <AnimatePresence mode="wait">
                <motion.div
                  key="timeline"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <Card className="border-0 shadow-lg bg-white/5 backdrop-blur-md">
                    <CardHeader>
                      <CardTitle className="text-white">Project Timeline</CardTitle>
                      <CardDescription className="text-gray-400">Estimated development schedule</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-8">
                        {[
                          {
                            phase: "Phase 1: Planning & Design",
                            duration: "1 Week",
                            tasks: [
                              "Requirements gathering and analysis",
                              "Wireframing and UI/UX design",
                              "Design approval and revisions",
                              "Technical architecture planning",
                            ],
                          },
                          {
                            phase: "Phase 2: Frontend Development",
                            duration: "1 Week",
                            tasks: [
                              "Core page structure implementation",
                              "Responsive design implementation",
                              "Product listing and detail pages",
                              "Shopping cart functionality",
                            ],
                          },
                          {
                            phase: "Phase 3: Backend Development",
                            duration: "1 Week",
                            tasks: [
                              "User authentication system",
                              "Product management system",
                              "Order processing system",
                              "Payment gateway integration",
                            ],
                          },
                          {
                            phase: "Phase 4: Testing & Deployment",
                            duration: "2 Days",
                            tasks: [
                              "Quality assurance testing",
                              "Performance optimization",
                              "Security testing",
                              "Deployment to production",
                            ],
                          },
                        ].map((phase, i) => (
                          <motion.div
                            key={i}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.1 + i * 0.1 }}
                            className="relative pl-8"
                          >
                            <div className="absolute left-0 top-0 h-full w-0.5 bg-gradient-to-b from-purple-500 to-indigo-500"></div>
                            <div className="absolute left-[-8px] top-0 h-4 w-4 rounded-full bg-purple-500"></div>
                            <div className="flex items-center justify-between mb-2">
                              <h3 className="text-white font-medium">{phase.phase}</h3>
                              <Badge variant="outline" className="bg-white/10 text-white border-white/20">
                                <Clock className="h-3 w-3 mr-1" />
                                {phase.duration}
                              </Badge>
                            </div>
                            <ul className="space-y-2 ml-4">
                              {phase.tasks.map((task, j) => (
                                <motion.li
                                  key={j}
                                  initial={{ opacity: 0, x: -10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ delay: 0.2 + j * 0.05 }}
                                  className="text-gray-300 text-sm list-disc"
                                >
                                  {task}
                                </motion.li>
                              ))}
                            </ul>
                          </motion.div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.5, duration: 0.5 }}
                    className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6"
                  >
                    <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-600/20 to-indigo-600/20 backdrop-blur-md">
                      <CardHeader>
                        <CardTitle className="text-white">Ongoing Support</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-gray-300 mb-4">
                          <span className="font-bold text-purple-400">I will be there for you long after launch.</span>{" "}
                          My commitment extends beyond the initial development phase:
                        </p>
                        <ul className="space-y-3">
                          {[
                            "Immediate bug fixes and critical updates",
                            "Regular maintenance and security patches",
                            "Feature enhancements and expansions as your business grows",
                            "Performance monitoring and optimization",
                            "Training for your team on system management",
                          ].map((item, i) => (
                            <motion.li
                              key={i}
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ delay: 0.1 + i * 0.05 }}
                              className="flex items-center text-gray-300"
                            >
                              <CheckCircle className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                              {item}
                            </motion.li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="border-0 shadow-lg bg-white/5 backdrop-blur-md">
                      <CardHeader>
                        <CardTitle className="text-white">Milestones & Deliverables</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {[
                            {
                              milestone: "Design Approval",
                              deliverable: "Complete UI/UX designs and wireframes",
                              timeline: "After 1 week (Video Conference)",
                            },
                            {
                              milestone: "Frontend Prototype",
                              deliverable: "Interactive prototype with core pages",
                              timeline: "After 1 week (Video Conference)",
                            },
                            {
                              milestone: "Backend Integration",
                              deliverable: "Functional product and user management",
                              timeline: "After 1 week (Video Conference)",
                            },
                            {
                              milestone: "Beta Launch",
                              deliverable: "Fully functional site for testing",
                              timeline: "After 1 week (Video Conference)",
                            },
                            {
                              milestone: "Full Launch",
                              deliverable: "Production-ready website",
                              timeline: "2 days after client provides hosting",
                            },
                          ].map((item, i) => (
                            <motion.div
                              key={i}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.1 + i * 0.1 }}
                              className="pb-3 border-b border-white/10"
                            >
                              <div className="flex justify-between items-center mb-1">
                                <h3 className="text-white font-medium">{item.milestone}</h3>
                                <Badge
                                  variant="outline"
                                  className="bg-indigo-500/20 text-indigo-300 border-indigo-500/30"
                                >
                                  {item.timeline}
                                </Badge>
                              </div>
                              <p className="text-gray-400 text-sm">{item.deliverable}</p>
                            </motion.div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                </motion.div>
              </AnimatePresence>
            </TabsContent>

            <TabsContent value="contact">
              <AnimatePresence mode="wait">
                <motion.div
                  key="contact"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <Card className="border-0 shadow-lg bg-white/5 backdrop-blur-md">
                      <CardHeader>
                        <CardTitle className="text-white">Contact Information</CardTitle>
                        <CardDescription className="text-gray-400">
                          Get in touch to discuss this proposal
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-6">
                          <div className="flex items-start">
                            <div className="h-10 w-10 rounded-full bg-purple-500/20 flex items-center justify-center mr-4">
                              <Mail className="h-5 w-5 text-purple-400" />
                            </div>
                            <div>
                              <h3 className="text-white font-medium">Email</h3>
                              <p className="text-gray-300">abdallah.haroun2002@gmail.com</p>
                              <p className="text-gray-400 text-sm mt-1">Available 24/7 for email inquiries</p>
                            </div>
                          </div>

                          <div className="flex items-start">
                            <div className="h-10 w-10 rounded-full bg-indigo-500/20 flex items-center justify-center mr-4">
                              <Phone className="h-5 w-5 text-indigo-400" />
                            </div>
                            <div>
                              <h3 className="text-white font-medium">Phone</h3>
                              <p className="text-gray-300">+20 100 122 7550</p>
                              <p className="text-gray-400 text-sm mt-1">Available 3:15pm-12pm GMT+3, Sunday-Thursday</p>
                            </div>
                          </div>

                          <div className="flex items-start">
                            <div className="h-10 w-10 rounded-full bg-blue-500/20 flex items-center justify-center mr-4">
                              <Calendar className="h-5 w-5 text-blue-400" />
                            </div>
                            <div>
                              <h3 className="text-white font-medium">Schedule a Meeting</h3>
                              <p className="text-gray-300">Book a video call to discuss the proposal</p>
                              <p className="mt-2 text-gray-400 text-sm">Contact me directly to arrange a discussion throw whatsapp</p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="space-y-6">
                      <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-600/20 to-indigo-600/20 backdrop-blur-md">
                        <CardHeader>
                          <CardTitle className="text-white">Next Steps</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ol className="space-y-4 relative pl-8 before:absolute before:left-3 before:top-0 before:h-full before:w-px before:bg-white/20">
                            {[
                              "Review this proposal and note any questions or concerns",
                              "Schedule a follow-up meeting to discuss details",
                              "Finalize requirements and project scope",
                              "Approve agreement and Begin the deployment process ",
                              "Make the initial payment and be happy",
                            ].map((step, i) => (
                              <motion.li
                                key={i}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: 0.1 + i * 0.1 }}
                                className="relative text-gray-300"
                              >
                                <div className="absolute left-[-30px] top-0 flex h-6 w-6 items-center justify-center rounded-full bg-purple-500 text-white text-xs">
                                  {i + 1}
                                </div>
                                {step}
                              </motion.li>
                            ))}
                          </ol>
                        </CardContent>
                      </Card>

                      <Card className="border-0 shadow-lg bg-white/5 backdrop-blur-md">
                        <CardHeader>
                          <CardTitle className="text-white">Conclusion</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-gray-300 mb-4">
                            This project delivers a professional e-commerce platform to showcase and sell Arabesque
                            products internationally, built for scalability and ready for future expansions (e.g.,
                            loyalty programs, marketing integrations, shipment tracking).
                          </p>
                          <p className="text-gray-300 mb-4">
                            Thank you for trusting me with your business. I look forward to supporting your growth
                            journey!
                          </p>
                          <div className="mt-6 pt-4 border-t border-white/10">
                            <div className="flex items-center">
                              <div className="h-12 w-12 rounded-full bg-gradient-to-r from-purple-600 to-indigo-600 flex items-center justify-center mr-4">
                                <span className="text-white font-bold text-lg">AH</span>
                              </div>
                              <div>
                                <h3 className="text-white font-medium">Abdallah haroun</h3>
                                <p className="text-gray-400 text-sm">Senior Web Developer & UI/UX Expert</p>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
            </TabsContent>
          </Tabs>
        </motion.div>
      </main>

      <footer className="border-t border-white/10 py-6 bg-black/20">
        <div className="container mx-auto px-4 text-center text-gray-400 text-sm">
          <p>© {new Date().getFullYear()} - Premium Web Development Services</p>
          <p className="mt-1">This proposal is confidential and intended only for Arabesque Products.</p>
        </div>
      </footer>
    </div>
  )
}
